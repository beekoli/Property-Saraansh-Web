<?php
/**
 * Plugin Name: Property Saraansh Core
 * Description: Registers the Properties custom post type and Advanced Custom Fields for the Next.js frontend.
 * Version: 1.0.0
 * Author: Property Saraansh
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * 1. Register Custom Post Type: Properties
 */
function ps_register_properties_cpt() {
    $labels = array(
        'name'                  => 'Properties',
        'singular_name'         => 'Property',
        'menu_name'             => 'Properties',
        'name_admin_bar'        => 'Property',
        'add_new'               => 'Add New',
        'add_new_item'          => 'Add New Property',
        'new_item'              => 'New Property',
        'edit_item'             => 'Edit Property',
        'view_item'             => 'View Property',
        'all_items'             => 'All Properties',
        'search_items'          => 'Search Properties',
        'not_found'             => 'No properties found.',
        'not_found_in_trash'    => 'No properties found in Trash.'
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'properties'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-building',
        'supports'           => array('title', 'editor', 'thumbnail', 'excerpt'),
        'show_in_rest'       => true, // Essential for Next.js REST API
    );

    register_post_type('properties', $args);
}
add_action('init', 'ps_register_properties_cpt');

/**
 * 2. Register Advanced Custom Fields (ACF)
 * Requires the Advanced Custom Fields plugin to be installed.
 */
function ps_register_acf_fields() {
    if (function_exists('acf_add_local_field_group')):

        // Fields for Properties CPT
        acf_add_local_field_group(array(
            'key' => 'group_properties_details',
            'title' => 'Property Details',
            'fields' => array(
                array(
                    'key' => 'field_prop_price',
                    'label' => 'Price',
                    'name' => 'price',
                    'type' => 'text',
                    'instructions' => 'e.g. ₹ 2.5 Cr*',
                    'show_in_rest' => true,
                ),
                array(
                    'key' => 'field_prop_location',
                    'label' => 'Location',
                    'name' => 'location',
                    'type' => 'text',
                    'instructions' => 'e.g. Sector 150, Noida',
                    'show_in_rest' => true,
                ),
                array(
                    'key' => 'field_prop_type',
                    'label' => 'Property Type',
                    'name' => 'property_type',
                    'type' => 'select',
                    'choices' => array(
                        'Commercial' => 'Commercial',
                        'Residential' => 'Residential',
                        'Ultra Luxury' => 'Ultra Luxury',
                    ),
                    'show_in_rest' => true,
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'properties',
                    ),
                ),
            ),
            'show_in_rest' => true,
        ));

        // Fields for Home Page
        acf_add_local_field_group(array(
            'key' => 'group_home_hero',
            'title' => 'Home Page Hero Details',
            'fields' => array(
                array(
                    'key' => 'field_home_title_1',
                    'label' => 'Hero Title Part 1',
                    'name' => 'hero_title_part1',
                    'type' => 'text',
                    'instructions' => 'e.g. Noida\'s Premier',
                    'show_in_rest' => true,
                ),
                array(
                    'key' => 'field_home_title_2',
                    'label' => 'Hero Title Part 2',
                    'name' => 'hero_title_part2',
                    'type' => 'text',
                    'instructions' => 'e.g. Real Estate Consultancy',
                    'show_in_rest' => true,
                ),
                array(
                    'key' => 'field_home_subtitle',
                    'label' => 'Hero Subtitle',
                    'name' => 'hero_subtitle',
                    'type' => 'textarea',
                    'show_in_rest' => true,
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'page',
                        'operator' => '==',
                        'value' => get_page_by_path('home') ? get_page_by_path('home')->ID : 0, // Fallback if not created yet
                    ),
                ),
                // Allow targeting by page template or simply show on any page named 'home'
                array(
                    array(
                        'param' => 'page_template',
                        'operator' => '==',
                        'value' => 'default',
                    ),
                ),
            ),
            'show_in_rest' => true,
        ));

    endif;
}
add_action('acf/init', 'ps_register_acf_fields');

// Ensure ACF to REST API formatting is active (Fallback if acf_format=standard is omitted in frontend)
add_filter('acf/settings/rest_api_format', function () {
    return 'standard';
});
