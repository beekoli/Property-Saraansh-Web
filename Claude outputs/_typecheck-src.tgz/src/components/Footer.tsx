import Link from 'next/link';
import Image from 'next/image';
import { getVideosWithRealtimeStats } from '@/lib/videos';

export default async function Footer() {
  const videos = await getVideosWithRealtimeStats();
  const latestVideos = videos.filter((v) => v.category !== 'Shorts').slice(0, 3);

  return (
    <footer className="bg-brand-dark text-brand-pale pt-16 pb-24 lg:py-16 border-t border-brand-light/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Column 1: Logo and Tagline */}
          <div className="col-span-1">
            <Link href="/" className="flex items-center mb-6 group">
              <Image
                src="/logo.png"
                alt="Property Saraansh Logo"
                width={260}
                height={80}
                className="h-16 w-auto object-contain transition-transform duration-300 group-hover:scale-105"
              />
            </Link>
            <p className="text-sm leading-relaxed mb-6 font-light">
              Your trusted YouTube-based real estate consultancy in Noida. We provide expert property reviews, market insights & investment guidance — all on YouTube.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://www.youtube.com/@PropertySaraansh"
                target="_blank"
                rel="noreferrer"
                className="text-brand-accent hover:text-brand-accent-light transition-colors"
                aria-label="YouTube"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
              </a>
              <a
                href="https://instagram.com/propertysaraansh"
                target="_blank"
                rel="noreferrer"
                className="text-brand-accent hover:text-brand-accent-light transition-colors"
                aria-label="Instagram"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
              </a>
              <a
                href="https://www.facebook.com/PropertySaraansh"
                target="_blank"
                rel="noreferrer"
                className="text-brand-accent hover:text-brand-accent-light transition-colors"
                aria-label="Facebook"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.469h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.469h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
              </a>
              <a
                href="https://www.linkedin.com/company/propertysaraansh/"
                target="_blank"
                rel="noreferrer"
                className="text-brand-accent hover:text-brand-accent-light transition-colors"
                aria-label="LinkedIn"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
              </a>
              <a
                href="https://x.com/propsaraansh"
                target="_blank"
                rel="noreferrer"
                className="text-brand-accent hover:text-brand-accent-light transition-colors"
                aria-label="Twitter X"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="col-span-1 md:col-span-1">
            <h3 className="text-brand-accent font-semibold mb-6 uppercase tracking-wider text-sm">Quick Links</h3>
            <div className="grid grid-cols-2 gap-4">
              <ul className="space-y-3 text-sm font-light">
                <li><Link href="/" className="hover:text-brand-accent transition-colors">Home</Link></li>
                <li><Link href="/about-us" className="hover:text-brand-accent transition-colors">About Us</Link></li>
                <li><Link href="/our-team" className="hover:text-brand-accent transition-colors">Our Team</Link></li>
                <li><Link href="/our-videos" className="hover:text-brand-accent transition-colors">Our Videos</Link></li>
                <li><Link href="/blog" className="hover:text-brand-accent transition-colors">Blogs</Link></li>
              </ul>
              <ul className="space-y-3 text-sm font-light">
                <li><Link href="/new-launches" className="hover:text-brand-accent transition-colors">New Launches</Link></li>
                <li><Link href="/properties" className="hover:text-brand-accent transition-colors">All Projects</Link></li>
                <li><Link href="/commercial-properties" className="hover:text-brand-accent transition-colors">Commercial</Link></li>
                <li><Link href="/residential-properties" className="hover:text-brand-accent transition-colors">Residential</Link></li>
                <li><Link href="/builders" className="hover:text-brand-accent transition-colors">Builders</Link></li>
                <li><Link href="/careers" className="hover:text-brand-accent transition-colors">Careers</Link></li>
                <li><Link href="/contact" className="hover:text-brand-accent transition-colors">Contact</Link></li>
              </ul>
            </div>
          </div>

          {/* Column 3: Latest Videos */}
          <div className="col-span-1">
            <h3 className="text-brand-accent font-semibold mb-6 uppercase tracking-wider text-sm">Latest from YouTube</h3>
            <div className="space-y-4">
              {latestVideos.map((video) => (
                <Link
                  key={video.slug}
                  href={`/our-videos/${video.slug}`}
                  className="flex gap-3 items-center group"
                >
                  <div className="w-20 h-14 bg-brand-light/20 rounded overflow-hidden relative flex-shrink-0">
                    <Image
                      src={video.thumbnail}
                      alt={video.title}
                      fill
                      sizes="80px"
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                      <svg className="w-6 h-6 text-brand-accent opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                    </div>
                  </div>
                  <div className="flex-1">
                    <p className="text-xs font-medium text-white group-hover:text-brand-accent transition-colors line-clamp-2 leading-relaxed">
                      {video.title}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-brand-light/20 text-sm flex flex-col md:flex-row justify-between items-center text-brand-pale/50 font-light">
          <p>&copy; {new Date().getFullYear()} Property Saraansh. All rights reserved.</p>
          <div className="mt-4 md:mt-0 space-x-6 flex">
            <Link href="/privacy-policy" className="hover:text-brand-accent transition-colors">Privacy Policy</Link>
            <Link href="#" className="hover:text-brand-accent transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
