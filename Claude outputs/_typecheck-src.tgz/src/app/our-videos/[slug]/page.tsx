import { Metadata } from 'next';
import Image from 'next/image';
import type { ReactNode } from 'react';
import { notFound, permanentRedirect } from 'next/navigation';
import Link from 'next/link';
import { Calendar, Eye, Video, ArrowLeft } from 'lucide-react';
import { getVideosWithRealtimeStats, getHydratedVideoBySlug, getVideoBySlug, videos } from '@/lib/videos';
import { getLiveVideoById, youtubeIdFromSlug } from '@/lib/latestLongVideos';
import { getManagedVideo, preferWP } from '@/lib/managedContent';
import { getRelatedToVideo } from '@/lib/relatedToVideo';
import { getChannelStats } from '@/lib/youtube';
import { parseChapters, toClips, extractChapterLines, durationToSeconds, FALLBACK_CHAPTERS } from '@/lib/videoChapters';
import VideoPlayer from '@/components/VideoPlayer';
import VideoChapters from './VideoChapters';
import WatchSidebarForm from './WatchSidebarForm';
import { FRONTEND_URL, parseDateToISO8601, durationToISO8601 } from '@/lib/seo';

export const revalidate = 60; // Revalidate every minute

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return videos.map((video) => ({
    slug: video.slug,
  }));
}

/**
 * A watch page is served for every video in the curated list, and — for
 * uploads that are too new to have a hand-written entry in videos.ts yet — for
 * any slug ending in a YouTube id belonging to this channel, resolved live from
 * the API. That is what lets a card on /our-videos always open the full watch
 * page here (player + lead form + schema) instead of 404ing or bouncing the
 * visitor out to YouTube.
 */
async function resolveVideo(slug: string) {
  const curated = getVideoBySlug(slug);
  if (curated) return curated;

  const youtubeId = youtubeIdFromSlug(slug);
  return youtubeId ? await getLiveVideoById(youtubeId) : null;
}

/**
 * Lays the WordPress "Videos" entry for this slug over the video's copy, field
 * by field: anything written in WordPress wins, anything left blank keeps what
 * src/lib/videos.ts (or the live YouTube lookup) already provides. `metaTitle`
 * is returned separately because editors write the complete SEO title in
 * WordPress, so it must not get " | Property Saraansh" appended to it.
 */
async function resolveVideoWithManagedCopy(slug: string) {
  const video = await resolveVideo(slug);
  if (!video) return null;

  const managed = await getManagedVideo(slug);
  if (!managed) return { video, metaTitle: undefined as string | undefined };

  return {
    video: {
      ...video,
      title: preferWP(managed.title, video.title),
      description: preferWP(managed.shortDescription, video.description),
      content: preferWP(managed.aboutThisVideo, video.content || ''),
    },
    metaTitle: managed.metaTitle,
    metaDescription: managed.metaDescription,
  };
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const resolved = await resolveVideoWithManagedCopy(slug);

  if (!resolved) {
    return {
      title: 'Video Not Found | Property Saraansh',
    };
  }

  const { video, metaTitle, metaDescription } = resolved;

  return {
    title: preferWP(metaTitle, `${video.title} | Property Saraansh`),
    description: preferWP(
      metaDescription,
      video.description || `Watch honest real estate project reviews, construction updates, and investment guides from Saraansh Seth on YouTube.`
    ),
    alternates: {
      canonical: `${FRONTEND_URL}/our-videos/${video.slug}`,
    },
    openGraph: {
      type: 'video.other',
      title: preferWP(metaTitle, `${video.title} | Property Saraansh`),
      description: preferWP(metaDescription, video.description || `Watch honest real estate project reviews on YouTube.`),
      images: [
        {
          url: video.thumbnail,
          width: 1200,
          height: 630,
          alt: video.focusKeyword,
        },
      ],
      videos: [{ url: `https://www.youtube.com/embed/${video.youtubeId}` }],
    },
    twitter: {
      card: "summary_large_image",
      title: preferWP(metaTitle, video.title),
      description: preferWP(metaDescription, video.description),
      images: [video.thumbnail],
    },
    other: {
      "robots": "index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1",
    },
  };
}

// Parse simple markdown links [label](/path) inside the content field so that
// internal links (blog post, property listing) are real crawlable anchors
// instead of plain text. Internal paths use next/link; external URLs open in
// a new tab.
function renderRichText(text: string) {
  // ReactNode, not JSX.Element: React 19's types no longer expose a global JSX
  // namespace, so `JSX.Element` fails the production type check.
  const parts: ReactNode[] = [];
  const re = /\[([^\]]+)\]\(([^)]+)\)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let k = 0;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    const label = m[1];
    const href = m[2];
    if (href.startsWith('/')) {
      parts.push(
        <Link key={`l${k++}`} href={href} className="text-brand-primary font-medium underline hover:no-underline">
          {label}
        </Link>
      );
    } else {
      parts.push(
        <a key={`a${k++}`} href={href} target="_blank" rel="noopener noreferrer" className="text-brand-primary font-medium underline hover:no-underline">
          {label}
        </a>
      );
    }
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

/**
 * Hand-written keyword sets for the VideoObject schema. Only a handful of
 * videos have these; everything else relies on the title and description.
 */
const VIDEO_KEYWORDS: Record<string, string> = {
  'noida-market-slowdown-2026':
    'Noida real estate slowdown 2026, Noida property market crash, builder strategy slow market, resale seller investor Noida, buyer tips Noida property, real estate India 2026',
  'godrej-arden-sigma-3-review':
    'godrej arden, godrej arden greater noida, godrej arden sigma 3, godrej arden price, godrej arden floor plan, godrej arden review, greater noida real estate 2026, godrej arden investment',
};

export default async function VideoWatchPage({ params }: PageProps) {
  const { slug } = await params;
  // Views and duration come from YouTube (getHydratedVideoBySlug); the words on
  // the page come from WordPress where they have been written there.
  const base = (await getHydratedVideoBySlug(slug)) ?? (await resolveVideo(slug));
  const managed = base ? await getManagedVideo(slug) : null;

  const video = base && {
    ...base,
    title: preferWP(managed?.title, base.title),
    description: preferWP(managed?.shortDescription, base.description),
    content: preferWP(managed?.aboutThisVideo, base.content || ''),
  };

  if (!video) {
    notFound();
  }

  // Canonical URL enforcement: if the visitor arrived on a non-canonical slug
  // (e.g. the YouTube-id fallback URL), 308-redirect to the video's clean slug
  // so search engines and users only ever see one URL per video.
  if (video.slug && slug !== video.slug) {
    permanentRedirect(`/our-videos/${video.slug}`);
  }

  // Fetch stats, the video list, and the pages that cover this same video.
  const [stats, videos, related] = await Promise.all([
    getChannelStats(),
    getVideosWithRealtimeStats(),
    getRelatedToVideo(video.youtubeId)
  ]);
  const relatedLinks = [related.property, related.blog].filter(
    (l): l is NonNullable<typeof l> => Boolean(l)
  );

  const isCurrentShort = video.category === 'Shorts';
  const relatedVideos = videos
    .filter((v) => v.slug !== video.slug && (isCurrentShort ? v.category === 'Shorts' : v.category !== 'Shorts'))
    .slice(0, 3);

  const isNoidaSlowdown = video.slug === 'noida-market-slowdown-2026';
  const keywords = VIDEO_KEYWORDS[video.slug];

  // Key moments, in order of precedence:
  //   1. WordPress (ps_video.chapters) — an editor overriding the wording
  //   2. the video's own YouTube description, where the timestamps already are
  //   3. the fallback map, for the two videos hardcoded before either existed
  // Reading YouTube by default is what makes this self-maintaining: a new
  // upload gets Key Moments without anyone touching WordPress.
  const durationSeconds = durationToSeconds(video.duration);
  const chapters = parseChapters(
    managed?.chapters ||
      extractChapterLines(video.youtubeDescription) ||
      FALLBACK_CHAPTERS[video.slug],
    durationSeconds
  );
  const clips = toClips(chapters, `${FRONTEND_URL}/our-videos/${video.slug}`);

  const videoJsonLd = {
    "@context": "https://schema.org",
    "@type": "VideoObject",
    "name": video.title,
    "description": video.description,
    "thumbnailUrl": [video.thumbnail],
    "uploadDate": parseDateToISO8601(video.publishedAt),
    "duration": durationToISO8601(video.duration),
    "contentUrl": `https://www.youtube.com/watch?v=${video.youtubeId}`,
    "embedUrl": `https://www.youtube.com/embed/${video.youtubeId}`,
    "url": `${FRONTEND_URL}/our-videos/${video.slug}`,
    // The real integer from YouTube. The previous expression multiplied the
    // digits of the display string by 1000, which turned "6.1K views" into
    // 61,000 and "741 views" into 741,000 — a claim to Google that the channel
    // could not support. When the API is unreachable there is no honest number
    // to state, so the property is omitted rather than guessed.
    ...(typeof video.viewCount === 'number' && video.viewCount > 0
      ? {
          "interactionStatistic": {
            "@type": "InteractionCounter",
            "interactionType": "https://schema.org/WatchAction",
            "userInteractionCount": video.viewCount
          }
        }
      : {}),
    "publisher": {
      "@type": "Organization",
      "name": "Property Saraansh",
      "url": FRONTEND_URL,
      "logo": {
        "@type": "ImageObject",
        "url": `${FRONTEND_URL}/logo.png`
      },
      "sameAs": [
        "https://www.youtube.com/@PropertySaraansh",
        "https://instagram.com/propertysaraansh",
        "https://www.facebook.com/PropertySaraansh",
        "https://www.linkedin.com/company/propertysaraansh/"
      ]
    },
    "author": {
      "@type": "Person",
      "name": "Saraansh Seth",
      "url": `${FRONTEND_URL}/about-us`
    },
    ...(keywords ? { "keywords": keywords } : {}),
    ...(isNoidaSlowdown && { "inLanguage": "hi-IN" }),
    // Google "Key Moments". Each clip URL must genuinely seek — the watch page
    // reads ?t= and passes start= to the embed, so these are compliant.
    ...(clips.length > 0 && { "hasPart": clips })
  };

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      { "@type": "ListItem", "position": 1, "name": "Home", "item": FRONTEND_URL },
      { "@type": "ListItem", "position": 2, "name": "Our Videos", "item": `${FRONTEND_URL}/our-videos` },
      { "@type": "ListItem", "position": 3, "name": video.title, "item": `${FRONTEND_URL}/our-videos/${video.slug}` }
    ]
  };

  const faqJsonLd = isNoidaSlowdown ? {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Is the Noida real estate market crashing in 2026?",
        "acceptedAnswer": { "@type": "Answer", "text": "No. The Noida real estate market is going through a slowdown or correction phase after a post-pandemic boom — not a crash. Prices have stabilized but have not fallen sharply. Demand has slowed but end-user activity continues." }
      },
      {
        "@type": "Question",
        "name": "Should I buy property in Noida during the slowdown?",
        "acceptedAnswer": { "@type": "Answer", "text": "If you are buying for self-use, this is a good time to negotiate. For investment, focus on mid-range resale properties with aggressive sellers rather than luxury launches. Avoid taking loans for pure investment in a slow market." }
      },
      {
        "@type": "Question",
        "name": "Will builders reduce prices in the Noida market slowdown?",
        "acceptedAnswer": { "@type": "Answer", "text": "Builders rarely slash prices directly in ongoing projects. Instead, they offer flexible payment plans like 20:80 or 40:60 as an affordability tool. However, paying more than 10% price top-up for such plans is not recommended for investors." }
      },
      {
        "@type": "Question",
        "name": "Should resale sellers panic and sell immediately?",
        "acceptedAnswer": { "@type": "Answer", "text": "No. If you have no urgent fund requirement and bought without a loan, hold your unit, take possession, rent it out, and wait 2–3 years for the market cycle to recover. Panic selling in a slow market leads to poor exits." }
      },
      {
        "@type": "Question",
        "name": "What is the best investment strategy in Noida property market 2026?",
        "acceptedAnswer": { "@type": "Answer", "text": "Look for distressed resale deals from motivated sellers, focus on mid-range projects with strong end-user demand, avoid luxury projects with slow habitation, and keep liquidity ready to act on genuine opportunities." }
      }
    ]
  } : null;

  const jsonLd = videoJsonLd;

  return (
    <>
      {/* Schema Markup for search engines */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      {faqJsonLd && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
        />
      )}

      <div className="min-h-screen bg-brand-pale flex flex-col pt-0">
        {/* Navigation Breadcrumb Banner */}
        <section className="bg-brand-dark pt-28 pb-8 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative z-10">
            <Link 
              href={video.category === 'Shorts' ? "/our-shorts" : "/our-videos"} 
              className="flex items-center gap-2 text-brand-accent hover:text-brand-accent-light transition-colors text-sm font-semibold uppercase tracking-wider group"
            >
              <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
              {video.category === 'Shorts' ? "Back to Property Shorts" : "Back to Video Reviews"}
            </Link>
            
            <div className="flex items-center gap-4 text-xs text-brand-pale/70">
              <span className="bg-brand-primary/50 text-brand-accent border border-brand-accent/30 px-3 py-1 rounded-full uppercase tracking-wider font-bold">
                {stats.subscriberCount} Subscribers
              </span>
            </div>
          </div>
        </section>

        {/* Watch Interface Grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-grow w-full">
          <div className="flex flex-col lg:flex-row gap-10 items-start">
            
            {/* Left Column: Player and Video Details */}
            <div className="w-full lg:w-8/12 space-y-8">
              {/* Responsive 16:9 Video Player Card */}
              <div id="video-player" className="bg-brand-dark p-3 rounded-2xl shadow-xl border border-brand-primary scroll-mt-28">
                <VideoPlayer videoId={video.youtubeId} title={video.title} isShort={video.category === 'Shorts'} />
              </div>

              {/* Video Title and Metadata */}
              <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-brand-light/10 space-y-4">
                <div className="flex flex-wrap gap-2.5">
                  <span className="bg-brand-pale text-brand-primary text-[10px] uppercase tracking-wider font-bold px-3 py-1 rounded">
                    {video.category}
                  </span>
                  <span className="bg-brand-accent/10 text-brand-accent border border-brand-accent/20 text-[10px] uppercase tracking-wider font-bold px-3 py-1 rounded">
                    {video.category === 'Shorts' ? '0:59 Mins' : video.duration.replace('PT', '').replace('M', ' Mins ').replace('S', ' Secs')}
                  </span>
                </div>

                <h1 className="heading-playfair text-2xl md:text-3xl font-bold text-brand-ink leading-tight">
                  {video.title}
                </h1>

                {video.description && (
                  <p className="text-sm md:text-base text-brand-ink/70 leading-relaxed mt-3">
                    {video.description}
                  </p>
                )}

                <div className="flex items-center gap-6 text-xs text-brand-light pt-2 border-t border-brand-pale font-light">
                  <span className="flex items-center gap-1.5">
                    <Calendar size={14} className="text-brand-primary" />
                    {video.publishedAt}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Eye size={14} className="text-brand-primary" />
                    {video.views}
                  </span>
                </div>
              </div>
              {/* Saraansh Verdict — the opinion this video gives on the
                  project. It lives here rather than on the property page so
                  the judgement sits with the review that produced it. */}
              {related.verdict && (
                <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-brand-light/10">
                  <h2 className="heading-playfair text-xl md:text-2xl font-bold text-brand-ink mb-5">
                    Saraansh Verdict
                  </h2>
                  <blockquote className="rounded-r-xl border-l-4 border-[#c9a24b] bg-[#fff7e0] p-5 text-[14.5px] italic text-[#4a3a12]">
                    {related.verdict
                      .split(/\n\s*\n/)
                      .map((para) => para.trim())
                      .filter(Boolean)
                      .map((para, i) => (
                        <p key={i} className={`hyphens-auto text-justify ${i > 0 ? 'mt-3' : ''}`}>
                          {para}
                        </p>
                      ))}
                    {related.property && (
                      <p className="mt-4 not-italic text-[13px]">
                        <Link
                          href={related.property.href}
                          className="font-semibold text-brand-primary hover:underline"
                        >
                          See {related.property.title} — price, floor plans and RERA details →
                        </Link>
                      </p>
                    )}
                  </blockquote>
                </div>
              )}

              {/* Key Moments — mirrors the Clip markup above */}
              <VideoChapters chapters={chapters} slug={video.slug} />

                          {/* Rich Content Section */}
              {video.content && (
                <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-brand-light/10">
                  <h2 className="heading-playfair text-xl md:text-2xl font-bold text-brand-ink mb-5">
                    About This Video
                  </h2>
                  <div className="text-justified text-sm text-brand-ink/80 leading-relaxed space-y-4">
                    {video.content.split('||').map((para, i) => (
                      <p key={i}>{renderRichText(para)}</p>
                    ))}
                  </div>
                </div>
              )}

              {/* FAQ Section — only for Noida Market Slowdown */}
              {isNoidaSlowdown && (
                <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-brand-light/10">
                  <h2 className="heading-playfair text-xl md:text-2xl font-bold text-brand-ink mb-6">
                    Frequently Asked Questions
                  </h2>
                  <div className="space-y-5">
                    {[
                      { q: "Is the Noida real estate market crashing in 2026?", a: "No. The Noida real estate market is going through a slowdown or correction phase after a post-pandemic boom — not a crash. Prices have stabilized but have not fallen sharply. Demand has slowed but end-user activity continues." },
                      { q: "Should I buy property in Noida during the slowdown?", a: "If you are buying for self-use, this is a good time to negotiate. For investment, focus on mid-range resale properties with aggressive sellers rather than luxury launches. Avoid taking loans for pure investment in a slow market." },
                      { q: "Will builders reduce prices in the Noida market slowdown?", a: "Builders rarely slash prices in ongoing projects. Instead, they offer flexible payment plans like 20:80 or 40:60 as an affordability tool. However, paying more than 10% price top-up for such plans is not recommended for investors." },
                      { q: "Should resale sellers panic and sell immediately?", a: "No. If you have no urgent fund requirement and bought without a loan, hold your unit, take possession, rent it out, and wait 2–3 years for the market cycle to recover. Panic selling in a slow market leads to poor exits." },
                      { q: "What is the best investment strategy in Noida property market 2026?", a: "Look for distressed resale deals from motivated sellers, focus on mid-range projects with strong end-user demand, avoid luxury projects with slow habitation, and keep liquidity ready to act on genuine opportunities." },
                    ].map((faq, i) => (
                      <div key={i} className="border-b border-brand-pale pb-5 last:border-0 last:pb-0">
                        <h3 className="text-sm font-semibold text-brand-ink mb-2">{faq.q}</h3>
                        <p className="text-sm text-brand-ink/70 leading-relaxed">{faq.a}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
</div>

            {/* Right Column: Sticky Lead Capture and Stats */}
            <div className="w-full lg:w-4/12 lg:sticky lg:top-28 space-y-6">
              
              {/* Consultation Lead Form Component */}
              <WatchSidebarForm videoTitle={video.title} />

              {/* Video Fact Sheet */}
              <div className="bg-brand-dark text-white p-6 rounded-2xl border border-brand-primary shadow-md">
                <h3 className="heading-playfair text-base font-bold text-brand-accent border-b border-brand-light/20 pb-3 mb-4">
                  Review Fact Sheet
                </h3>
                <table className="w-full text-xs font-light space-y-3">
                  <tbody>
                    <tr className="border-b border-brand-light/10">
                      <td className="py-2.5 text-brand-accent/80 font-medium">Channel</td>
                      <td className="py-2.5 text-right font-normal">Property Saraansh</td>
                    </tr>
                    <tr className="border-b border-brand-light/10">
                      <td className="py-2.5 text-brand-accent/80 font-medium">Presenter</td>
                      <td className="py-2.5 text-right font-normal">Saraansh Seth</td>
                    </tr>
                    <tr className="border-b border-brand-light/10">
                      <td className="py-2.5 text-brand-accent/80 font-medium">Category</td>
                      <td className="py-2.5 text-right font-normal">{video.category}</td>
                    </tr>
                    <tr className="border-b border-brand-light/10">
                      <td className="py-2.5 text-brand-accent/80 font-medium">Review Date</td>
                      <td className="py-2.5 text-right font-normal">{video.publishedAt}</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 text-brand-accent/80 font-medium">Focus Area</td>
                      <td className="py-2.5 text-right font-normal">Noida & Greater Noida</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* RERA Warning Badge */}
              <div className="border border-brand-primary/40 bg-brand-primary/10 rounded-2xl p-5 text-center">
                <span className="inline-block bg-brand-accent/20 border border-brand-accent/30 text-brand-accent text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-2">
                  RERA Compliant Advisory
                </span>
                <p className="text-[11px] text-brand-ink/80 font-light leading-relaxed">
                  We verify all projects on the UP RERA portal before filing video reviews. Always consult our advisors to verify registrations, pricing sheets, and payment plans.
                </p>
              </div>
            </div>
          </div>

          {/* Outbound links. A watch page receives internal links from the
              property page and the blog post, and used to return none — the
              shape Google reads as a low-value orphan. These send authority
              back to the two pages that actually convert. */}
          {relatedLinks.length > 0 && (
            <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-brand-light/10">
              <h2 className="heading-playfair text-xl md:text-2xl font-bold text-brand-ink mb-2">
                Related to this project
              </h2>
              <p className="text-sm text-brand-ink/60 mb-5">
                Everything else on the site about what this video covers.
              </p>
              <div className="grid gap-3 sm:grid-cols-2">
                {relatedLinks.map((link) => (
                  <Link
                    key={link.href}
                    href={link.href}
                    className="group block rounded-xl border border-brand-pale hover:border-brand-light bg-brand-pale/30 hover:bg-brand-pale/60 transition-colors p-4"
                  >
                    <span className="block text-sm font-bold text-brand-ink group-hover:text-brand-primary transition-colors leading-snug">
                      {link.title}
                    </span>
                    <span className="block text-[11px] text-brand-ink/60 mt-1.5 leading-relaxed">
                      {link.blurb}
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Related Videos Section */}
          {relatedVideos.length > 0 && (
                          <div className="mt-20 pt-10 border-t border-brand-light/10">
              <h2 className="heading-playfair text-2xl md:text-3xl text-brand-ink font-bold mb-10 text-center inline-block relative left-1/2 -translate-x-1/2">
                Related Video Reviews
                <span className="absolute bottom-0 left-0 w-full h-0.5 bg-brand-accent -mb-2"></span>
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {relatedVideos.map((item) => (
                  <div 
                    key={item.slug} 
                    className="group bg-white rounded-xl overflow-hidden border border-brand-pale hover:shadow-lg transition-all duration-300 flex flex-col h-full relative"
                  >
                    <Link 
                      href={`/our-videos/${item.slug}`}
                      className="relative aspect-video overflow-hidden bg-brand-dark block"
                    >
                      <Image
                        src={item.thumbnail}
                        alt={item.title}
                        fill
                        sizes="(max-width: 768px) 100vw, 33vw"
                        className="object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      <div className="absolute top-3 left-3 bg-brand-primary text-white text-[9px] uppercase tracking-wider font-bold px-2.5 py-1 rounded">
                        {item.category}
                      </div>
                      <div className="absolute inset-0 bg-brand-primary/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                        <svg className="w-12 h-12 text-brand-accent transform scale-50 group-hover:scale-100 transition-all" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/>
                        </svg>
                      </div>
                    </Link>
                    
                    <div className="p-4 flex-grow flex flex-col justify-between">
                      <Link 
                        href={`/our-videos/${item.slug}`}
                        className="block"
                      >
                        <h3 className="text-xs font-semibold text-black line-clamp-2 leading-relaxed group-hover:text-brand-primary transition-colors">
                          {item.title}
                        </h3>
                      </Link>
                      <div className="text-[10px] text-brand-light/80 mt-3 pt-2.5 border-t border-brand-pale font-light flex justify-between">
                        <span>{item.publishedAt}</span>
                        <span>{item.views}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
