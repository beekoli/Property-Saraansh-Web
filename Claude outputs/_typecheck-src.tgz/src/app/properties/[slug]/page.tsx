import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { generateRankMathMetadata } from '@/lib/seo';
import { getProperty, buildSchemas, SITE, getBuilderProfile } from '@/lib/property';
import { getPropertyVideoCta } from '@/lib/propertyVideoCta';
import PropertyDetail from '@/components/property/PropertyDetail';

export const revalidate = 300;

interface PageProps {
  params: Promise<{ slug: string }>;
}

/**
 * Deliberately empty.
 *
 * Prerendering every property at build time meant one WordPress hiccup during
 * a build baked that property as a static 404, served to users and Googlebot
 * until the next deploy. SOBHA Aurum did exactly that: correct on one deploy,
 * a hard 404 on the next, while still linked from /properties.
 *
 * Pages now render on first request and are then ISR-cached (see revalidate
 * above), so a transient WordPress failure costs one slow request instead of a
 * persistent 404. dynamicParams defaults to true, which is what allows this.
 */
export async function generateStaticParams() {
  return [];
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const p = await getProperty(slug);
  if (!p) return { title: 'Property Not Found' };

  const fallbackTitle = `${p.title} | Price, Floor Plan & Review — Property Saraansh`;
  const fallbackDesc = p.tagline || `View price, floor plans, payment plan and our video review of ${p.title}.`;
  const url = `${SITE}/properties/${p.slug}`;

  // Priority: new ACF SEO tab (meta_title/meta_description, with seo_title
  // fallback inside lib) → RankMath/Yoast JSON → fallbacks
  const seoJson = p.seoJson as Parameters<typeof generateRankMathMetadata>[0];
  const metadata = generateRankMathMetadata(seoJson, fallbackTitle, fallbackDesc);

  if (p.metaTitle) {
    metadata.title = p.metaTitle;
    if (metadata.openGraph) (metadata.openGraph as Record<string, unknown>).title = p.metaTitle;
    if (metadata.twitter) (metadata.twitter as Record<string, unknown>).title = p.metaTitle;
  }
  if (p.metaDescription) {
    metadata.description = p.metaDescription;
    if (metadata.openGraph) (metadata.openGraph as Record<string, unknown>).description = p.metaDescription;
    if (metadata.twitter) (metadata.twitter as Record<string, unknown>).description = p.metaDescription;
  }

  metadata.alternates = { ...(metadata.alternates ?? {}), canonical: url };
  // Explicit robots directive for consistency with blog/video pages (property
  // pages previously emitted no robots meta and relied on the crawler default).
  metadata.robots = 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1';
  if (p.hero) {
    metadata.openGraph = {
      ...(metadata.openGraph ?? {}),
      url,
      images: [{ url: p.hero.url, width: 1200, height: 630, alt: p.title }],
    } as Metadata['openGraph'];
  }

  return metadata;
}

export default async function PropertyPage({ params }: PageProps) {
  const { slug } = await params;
  const property = await getProperty(slug);
  if (!property) notFound();

  // Builder profile (logo, description, trust stats) from the ps_builder tag,
  // used for the "Meet the Builder" section + link to /builders/[slug].
  // videoCta is null for the 39 projects we have not reviewed, and for the
  // three that embed a developer walkthrough — the card then renders nothing.
  const [builder, videoCta] = await Promise.all([
    getBuilderProfile(property.builderSlug),
    getPropertyVideoCta(property.youtubeId),
  ]);

  return (
    <>
      {buildSchemas(property).map((schema, i) => (
        <script
          key={i}
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
        />
      ))}
      <PropertyDetail p={property} builder={builder} videoCta={videoCta} />
    </>
  );
}
