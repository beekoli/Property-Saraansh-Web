/**
 * Property Saraansh — data layer for the property detail page (v2 fields)
 * Fetches from WordPress REST (new SCF field structure) and normalizes
 * everything the page needs, resolving media IDs → URLs in ONE batched
 * /media request.
 *
 * NOTE: unlike lib/wordpress.ts, responses are NOT hostname-rewritten —
 * next/image remotePatterns allows the WP host (login.propertysaraansh.com),
 * and rewriting image URLs to the frontend host breaks image optimization.
 */

import type { WPBuilderTerm, WPProperty } from "@/lib/wordpress";
import { formatReraDate } from "@/lib/formatDate";

import { decodeHtml } from "@/lib/decodeHtml";

const API = process.env.NEXT_PUBLIC_WORDPRESS_API_URL || "https://login.propertysaraansh.com/wp-json/wp/v2";
export const SITE = (process.env.NEXT_PUBLIC_SITE_URL || "https://www.propertysaraansh.com").replace(/\/$/, "");

/**
 * WordPress cannot cope with the burst of parallel requests a full static
 * build produces — it starts returning 500s. Historically those 500s were
 * swallowed and the page was baked as a 404, which is the root cause of the
 * intermittent missing listings.
 *
 * Two mitigations here:
 *   1. A small concurrency gate so we never hit WP with more than a handful
 *      of requests at once.
 *   2. Patient retries with exponential backoff and jitter.
 *
 * A genuine 404 from WordPress still returns null so the caller can call
 * notFound(). Anything else throws, so we never silently serve a 404 for a
 * page that actually exists.
 */
const MAX_CONCURRENT_WP_REQUESTS = 4;
let activeWpRequests = 0;
const wpQueue: (() => void)[] = [];

async function withWpLimit<T>(fn: () => Promise<T>): Promise<T> {
  if (activeWpRequests >= MAX_CONCURRENT_WP_REQUESTS) {
    await new Promise<void>((resolve) => wpQueue.push(resolve));
  }
  activeWpRequests++;
  try {
    return await fn();
  } finally {
    activeWpRequests--;
    wpQueue.shift()?.();
  }
}

async function wpFetch(endpoint: string, attempts = 5): Promise<unknown> {
  let lastErr: unknown = null;

  for (let i = 0; i < attempts; i++) {
    try {
      const res = await withWpLimit(() =>
        fetch(`${API}${endpoint}`, { next: { revalidate: 300 } })
      );

      // WordPress positively says it is not there — a real 404.
      if (res.status === 404) return null;

      if (res.ok) return await res.json();

      lastErr = new Error(`WP responded ${res.status} for ${endpoint}`);
    } catch (err) {
      lastErr = err;
    }

    if (i < attempts - 1) {
      // 400ms, 1.2s, 3.6s, 10.8s (+ jitter) — WP recovers given a moment
      const backoff = 400 * Math.pow(3, i);
      await new Promise((r) => setTimeout(r, backoff + Math.random() * 300));
    }
  }

  // NOTE: we deliberately return null rather than throwing.
  //
  // Throwing is the theoretically correct behaviour (a timeout is not a 404),
  // but WordPress currently 500s under the request burst of a full static
  // build, so throwing fails the deploy outright. The retries and concurrency
  // gate above already remove the large majority of transient failures.
  //
  // The complete fix is to stop prerendering all property pages against a
  // fragile WordPress: return [] from generateStaticParams and let pages
  // render on demand with ISR. Once that is in place this should throw.
  console.error("property.ts fetch failed after retries:", endpoint, lastErr);
  return null;
}

/* ---------------- types ---------------- */

export interface Img { url: string; alt: string; width?: number; height?: number }

export interface CityTerm { id: number; name: string; slug: string; count: number }

export interface Property {
  id: number;
  slug: string;
  title: string;
  hero: Img | null;
  tagline: string;
  rera: string;
  launchDate: string;
  possessionDate: string;
  /** Proposed completion date from the UP RERA registration, stored as YYYY-MM-DD. */
  reraCompletionDate: string;
  /** Proposed start of construction from the UP RERA registration, YYYY-MM-DD. */
  reraStartDate: string;
  basePrice: string;
  priceDisplay: string;
  priceMin: number | null;
  priceMax: number | null;
  configuration: string;
  city: string;
  sector: string;
  builder: string;
  builderSlug: string;
  type: string;
  status: string;
  overviewHtml: string;
  quickFacts: { label: string; value: string }[];
  youtubeId: string;
  verdict: string;
  highlights: string[];
  masterPlan: Img | null;
  sitePlan: Img | null;
  floorPlans: { title: string; description: string; image: Img | null; pdf: string }[];
  floorPlanNote: string;
  amenities: { icon: string; name: string; image: Img | null }[];
  priceList: { type: string; size: string; base: string; total: string }[];
  priceNote: string;
  priceListPdf: string;
  paymentSteps: { percentage: string; title: string; description: string }[];
  paymentMilestones: { milestone: string; demand: string; cumulative: string }[];
  eoiNote: string;
  address: string;
  lat: string;
  lng: string;
  locationAdv: { category: string; name: string; distance: string }[];
  mapEmbedSrc: string;
  gallery: Img[];
  logo: Img | null;
  brochurePdf: string;
  currentPhase: string;
  timeline: { stage: string; date: string; done: boolean }[];
  faqs: { question: string; answer: string }[];
  metaTitle: string;
  metaDescription: string;
  seoJson: unknown;
  publishedDate: string;
  modifiedDate: string;
}

/* ---------------- helpers ---------------- */

export const ytId = (url: string): string =>
  url?.match(/(?:v=|youtu\.be\/|embed\/)([\w-]{11})/)?.[1] ?? "";

const iframeSrc = (html: string): string =>
  html?.match(/src="([^"]+)"/)?.[1] ?? "";

type RawImg = number | string | { ID?: number; id?: number; url?: string; alt?: string } | null | false;

function collectId(v: RawImg): number | null {
  if (typeof v === "number") return v;
  if (typeof v === "string" && /^\d+$/.test(v)) return parseInt(v, 10);
  if (v && typeof v === "object") return v.ID ?? v.id ?? null;
  return null;
}

interface WPMedia { id: number; source_url: string; alt_text?: string; media_details?: { width?: number; height?: number } }

async function resolveMedia(ids: number[]): Promise<Record<number, Img>> {
  if (!ids.length) return {};
  const uniq = [...new Set(ids)];
  const items = (await wpFetch(
    `/media?include=${uniq.join(",")}&per_page=${uniq.length}&_fields=id,source_url,alt_text,media_details`
  )) as WPMedia[] | null;
  const map: Record<number, Img> = {};
  for (const m of items ?? []) {
    map[m.id] = { url: m.source_url, alt: m.alt_text || "", width: m.media_details?.width, height: m.media_details?.height };
  }
  return map;
}

function toImg(v: RawImg, media: Record<number, Img>, altFallback: string): Img | null {
  const id = collectId(v);
  if (id && media[id]) return { ...media[id], alt: media[id].alt || altFallback };
  if (v && typeof v === "object" && v.url) return { url: v.url, alt: v.alt || altFallback };
  if (typeof v === "string" && v.startsWith("http")) return { url: v, alt: altFallback };
  return null;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
const termName = (p: any, tax: string): string =>
  p._embedded?.["wp:term"]?.flat().find((t: any) => t.taxonomy === tax)?.name ?? "";

const termSlug = (p: any, tax: string): string =>
  p._embedded?.["wp:term"]?.flat().find((t: any) => t.taxonomy === tax)?.slug ?? "";

// City-level slugs in the ps_location taxonomy. Everything else on a property
// (Sector 94, Omicron 1A, C1 Jaypee Greens, …) is treated as the sector/area.
const CITY_SLUGS = new Set([
  "noida", "greater-noida", "noida-extension", "yamuna-expressway",
  "ghaziabad", "delhi", "gurgaon", "gurugram", "faridabad",
]);

/* ---------------- fetch + normalize ---------------- */

export async function getAllPropertySlugs(): Promise<string[]> {
  try {
    const posts = (await wpFetch(`/properties?per_page=100&_fields=slug`)) as { slug: string }[] | null;
    return (posts ?? []).map((p) => p.slug);
  } catch {
    return []; // build-time listing — never fail the whole build on a blip
  }
}

/**
 * Builder profile (logo, description, trust stats) for the ps_builder term.
 * Fetched via this module's wpFetch (which has a hardcoded API fallback) so
 * the "Meet the Builder" section works on Preview deployments too.
 */
export async function getBuilderProfile(slug: string): Promise<WPBuilderTerm | null> {
  if (!slug) return null;
  try {
    const data = (await wpFetch(
      `/builder?slug=${encodeURIComponent(slug)}&_fields=id,name,slug,count,acf`
    )) as WPBuilderTerm[] | null;
    if (!data || !Array.isArray(data) || data.length === 0) return null;
    return { ...data[0], name: decodeHtml(data[0].name) };
  } catch {
    return null; // builder card is optional — never fail the page for it
  }
}

/**
 * City terms (ps_location taxonomy, rest base "location") whose slug is a known
 * city — used to build the /property-in/[city] landing pages.
 */
export async function getCities(): Promise<CityTerm[]> {
  try {
    const data = (await wpFetch(`/location?per_page=100&_fields=id,name,slug,count`)) as CityTerm[] | null;
    return (data ?? []).filter((t) => CITY_SLUGS.has(t.slug));
  } catch {
    return [];
  }
}

export async function getCityBySlug(slug: string): Promise<CityTerm | null> {
  if (!slug) return null;
  try {
    const data = (await wpFetch(`/location?slug=${encodeURIComponent(slug)}&_fields=id,name,slug,count`)) as CityTerm[] | null;
    return data && Array.isArray(data) && data.length > 0 ? data[0] : null;
  } catch {
    return null;
  }
}

/** Raw properties (with _embed) tagged with a given ps_location term id. */
export async function getPropertiesInCity(termId: number, limit = 50): Promise<WPProperty[]> {
  try {
    const data = (await wpFetch(`/properties?_embed&per_page=${limit}&location=${termId}`)) as WPProperty[] | null;
    return data && Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

export async function getProperty(slug: string): Promise<Property | null> {
  const posts = (await wpFetch(`/properties?slug=${encodeURIComponent(slug)}&_embed`)) as any[] | null;
  const p = posts?.[0];
  if (!p) return null;
  const a = p.acf ?? {};

  // City + sector from the single ps_location taxonomy: the term whose slug is
  // a known city becomes the city, the remaining term becomes the sector.
  // Non-ps `location` taxonomy + old flat fields stay as fallbacks.
  const psLocTerms: any[] = (p._embedded?.["wp:term"]?.flat() ?? []).filter((t: any) => t.taxonomy === "ps_location");
  const cityTerm = psLocTerms.find((t: any) => CITY_SLUGS.has(t.slug));
  const sectorTerm = psLocTerms.find((t: any) => !CITY_SLUGS.has(t.slug));

  const rawImgs: RawImg[] = [
    a.master_plan, a.site_plan, a.logo_image,
    ...(Array.isArray(a.gallery) ? a.gallery : []),
    ...(Array.isArray(a.floor_plans) ? a.floor_plans.map((f: any) => f.image) : []),
    ...(Array.isArray(a.amenities) ? a.amenities.map((m: any) => m.image) : []),
  ];
  const media = await resolveMedia(rawImgs.map(collectId).filter((n): n is number => !!n));

  const heroUrl: string | null = p._embedded?.["wp:featuredmedia"]?.[0]?.source_url ?? null;
  const title: string = decodeHtml(p.title?.rendered ?? "");

  // fallbacks to old flat fields keep the page rendering even before a
  // property is fully migrated to the new structure
  const highlights: string[] = Array.isArray(a.highlights_list) && a.highlights_list.length
    ? a.highlights_list.map((h: any) => h.text).filter(Boolean)
    : String(a.highlights || "").split(";").map((s: string) => s.trim()).filter(Boolean);

  const gallery: Img[] = (Array.isArray(a.gallery) && a.gallery.length
    ? a.gallery.map((g: RawImg, i: number) => toImg(g, media, `${title} gallery image ${i + 1}`))
    : Array.from({ length: 10 }, (_, i) => toImg(a[`gallery_image_${i + 1}`], media, `${title} gallery image ${i + 1}`))
  ).filter((g: Img | null): g is Img => !!g);

  return {
    id: p.id,
    slug: p.slug,
    title,
    hero: heroUrl ? { url: heroUrl, alt: title } : (gallery[0] ?? null),
    tagline: a.tagline || a.property_tagline || "",
    rera: a.rera_number || "",
    launchDate: a.launch_date || "",
    possessionDate: a.possession_date || "",
    reraCompletionDate: a.rera_completion_date || "",
    reraStartDate: a.rera_start_date || "",
    basePrice: a.base_price || "",
    priceDisplay: a.price_display || a.price || "",
    priceMin: a.price_min_numeric ? Number(a.price_min_numeric) : null,
    priceMax: a.price_max_numeric ? Number(a.price_max_numeric) : null,
    configuration: a.configuration || "",
    city: cityTerm?.name || termName(p, "location") || a.location_city || "Noida",
    sector: sectorTerm?.name || a.location_sector || "",
    builder: decodeHtml(termName(p, "ps_builder") || termName(p, "builder") || a.developer_name || a.developer || ""),
    builderSlug: termSlug(p, "ps_builder") || termSlug(p, "builder") || "",
    type: termName(p, "ps_property_type") || termName(p, "property_type") || a.property_type || "",
    status: termName(p, "ps_project_status") || termName(p, "project_status") || a.property_status || "",
    overviewHtml: a.project_overview || p.content?.rendered || "",
    quickFacts: ([
      ["Total Land", a.quick_facts?.total_land || a.total_land],
      ["Towers", a.quick_facts?.total_towers],
      ["Total Units", a.quick_facts?.total_units || a.total_units],
      ["Total Floors", a.quick_facts?.total_floors || a.total_floors],
      ["Units / Floor", a.quick_facts?.units_per_floor || a.units_per_floor],
      ["Lifts / Floor", a.quick_facts?.lifts_per_floor || a.lifts_per_floor],
      ["Configuration", a.configuration],
      // The launch date IS the UP RERA registration date, so this reads as
      // "RERA Received". A separate Launch tile would repeat the same value.
      ["RERA Received", formatReraDate(a.launch_date)],
      ["Possession", a.possession_date],
      // The regulator's own date, shown beside our possession wording rather
      // than replacing it — the two are different claims and a buyer benefits
      // from seeing both.
      ["RERA Completion", formatReraDate(a.rera_completion_date)],
      ["RERA No.", a.rera_number],
      ["Base Price", a.base_price],
    ] as [string, string | undefined][]).filter(([, v]) => v).map(([label, value]) => ({ label, value: value as string })),
    youtubeId: ytId(a.youtube_url || "") || a.video_id || "",
    verdict: a.video_review_text || "",
    highlights,
    masterPlan: toImg(a.master_plan, media, `${title} master layout plan`),
    sitePlan: toImg(a.site_plan, media, `${title} site plan map`),
    floorPlans: (Array.isArray(a.floor_plans) ? a.floor_plans : []).map((f: any) => ({
      title: f.title || "", description: f.description || "",
      image: toImg(f.image, media, `${title} floor plan — ${f.title}`), pdf: f.pdf || "",
    })),
    floorPlanNote: a.floor_plan_note || a.floor_plan_footer_text || "",
    amenities: (Array.isArray(a.amenities) ? a.amenities : []).map((m: any) => ({
      icon: m.icon || "✨",
      name: m.name || "",
      // Optional photo for the amenity. Listings without one keep rendering as icon + name.
      image: toImg(m.image, media, `${title} — ${m.name || "amenity"}`),
    })),
    priceList: Array.isArray(a.price_list) ? a.price_list : [],
    priceNote: a.price_note || a.price_list_desc || "",
    priceListPdf: a.price_list_pdf || "",
    paymentSteps: Array.isArray(a.payment_steps) ? a.payment_steps : [],
    paymentMilestones: Array.isArray(a.payment_milestones) ? a.payment_milestones : [],
    eoiNote: a.eoi_note || a.payment_eoi_note || "",
    address: a.address || [a.location, a.location_city].filter(Boolean).join(", "),
    lat: a.latitude || "",
    lng: a.longitude || "",
    locationAdv: Array.isArray(a.location_adv) ? a.location_adv : [],
    mapEmbedSrc: iframeSrc(a.google_map_embed || ""),
    gallery,
    logo: toImg(a.logo_image, media, `${a.developer_name || ""} — ${title} logo`),
    brochurePdf: a.brochure_pdf || "",
    currentPhase: a.current_phase || "launch",
    timeline: Array.isArray(a.construction_timeline) ? a.construction_timeline : [],
    faqs: Array.isArray(a.faqs) ? a.faqs : [],
    metaTitle: a.meta_title || a.seo_title || "",
    metaDescription: a.meta_description || a.seo_description || "",
    seoJson: p.rank_math_json || p.yoast_head_json || null,
    publishedDate: p.date,
    modifiedDate: p.modified,
  };
}

/* ---------------- JSON-LD ---------------- */

export function buildSchemas(prop: Property) {
  const url = `${SITE}/properties/${prop.slug}`;
  const citySlug = prop.city.toLowerCase().replace(/\s+/g, "-");
  const fact = (label: string): string => prop.quickFacts.find((f) => f.label === label)?.value ?? "";
  const unitCount = parseInt(fact("Total Units").replace(/[^0-9]/g, ""), 10) || null;
  // A launch that has not been handed over is not "in stock" — it is a pre-order.
  const readyToMove = /ready\s*to\s*move|possession|completed|delivered/i.test(
    `${prop.status} ${prop.currentPhase}`
  );
  const availability = readyToMove
    ? "https://schema.org/InStock"
    : "https://schema.org/PreOrder";

  const apartmentComplex = {
    "@context": "https://schema.org",
    "@type": "ApartmentComplex",
    "@id": `${url}#project`,
    name: prop.title,
    url,
    image: prop.hero?.url,
    description: prop.metaDescription || prop.tagline,
    address: {
      "@type": "PostalAddress",
      streetAddress: prop.address,
      addressLocality: prop.city,
      addressRegion: "Uttar Pradesh",
      addressCountry: "IN",
    },
    ...(prop.lat && prop.lng ? { geo: { "@type": "GeoCoordinates", latitude: prop.lat, longitude: prop.lng } } : {}),
    amenityFeature: prop.amenities.map((m) => ({ "@type": "LocationFeatureSpecification", name: m.name, value: true })),
    ...(unitCount ? { numberOfAvailableAccommodationUnits: { "@type": "QuantitativeValue", value: unitCount } } : {}),
    ...(prop.builder ? { brand: { "@type": "Organization", name: prop.builder } } : {}),
  };

  // Product is emitted for every listing so all projects are eligible for a
  // Product rich result. The offers block is included only when the developer
  // has actually published a price — we never assert a price we do not have.
  const hasPrice = Boolean(prop.priceMin || prop.priceMax);

  const product = {
    "@context": "https://schema.org",
    "@type": "Product",
    "@id": `${url}#product`,
    name: `${prop.title} — ${prop.configuration}`.trim(),
    image: prop.hero?.url,
    description: prop.tagline || prop.metaDescription,
    brand: { "@type": "Brand", name: prop.builder || "Property Saraansh" },
    category: prop.type || "Residential",
    ...(prop.rera ? { sku: prop.rera } : {}),
    additionalProperty: ([
      ["RERA Registration Number", prop.rera],
      ["Possession", prop.possessionDate],
      ["Total Land", fact("Total Land")],
      ["Towers", fact("Towers")],
      ["Total Units", fact("Total Units")],
    ] as [string, string][])
      .filter(([, v]) => v)
      .map(([name, value]) => ({ "@type": "PropertyValue", name, value })),
    ...(hasPrice ? {
      offers: {
        "@type": "AggregateOffer",
        priceCurrency: "INR",
        ...(prop.priceMin ? { lowPrice: prop.priceMin } : {}),
        ...(prop.priceMax ? { highPrice: prop.priceMax } : {}),
        offerCount: prop.priceList.length || 1,
        availability,
        url,
      },
    } : {}),
  };

  const faqPage = prop.faqs.length ? {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: prop.faqs.map((f) => ({
      "@type": "Question", name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  } : null;

  const breadcrumbs = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE },
      { "@type": "ListItem", position: 2, name: "Projects", item: `${SITE}/properties` },
      { "@type": "ListItem", position: 3, name: prop.city, item: `${SITE}/property-in/${citySlug}` },
      { "@type": "ListItem", position: 4, name: prop.title, item: url },
    ],
  };

  // NO VideoObject here, deliberately.
  //
  // Every property with a youtubeId used to emit one, which meant the property
  // page and the /our-videos watch page both claimed the same video. Google
  // then has to pick a winner for that video, and the page it should pick is
  // the watch page — that one exists for the video, carries its transcript and
  // description, and is what the video sitemap points at.
  //
  // The blog template was cleaned up for exactly this reason (PR #54); this is
  // the same fix at the property template, so it applies to all 60 properties
  // rather than the one that was corrected by hand.
  //
  // The video itself still plays on the property page. Only the competing
  // structured-data claim is gone, and the watch page is linked from here so
  // the relationship stays legible to a crawler.

  return [apartmentComplex, product, faqPage, breadcrumbs].filter(Boolean);
}
